# @xpert-ai/chatkit-angular

Angular 17+ standalone bindings for Xpert Chatkit.

## Install

```bash
pnpm add @xpert-ai/chatkit-angular @angular/core
```

## Usage

```ts
import { Component } from '@angular/core';
import { ChatKit, createChatKit } from '@xpert-ai/chatkit-angular';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ChatKit],
  template: `
    <xpert-chatkit [control]="chatkit" style="height: 100vh;"></xpert-chatkit>
  `,
})
export class AppComponent {
  readonly chatkit = createChatKit({
    frameUrl: '<url-to-chatkit-frame>',
    api: {
      apiUrl: 'https://api.xpertai.cn',
      xpertId: 'your-assistant-id',
      getClientSecret: async () => {
        const response = await fetch('/api/create-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();
        return data.client_secret;
      },
    },
    onReady: () => {
      console.log('ChatKit is ready');
    },
  });
}
```

## API

### `createChatKit(options)`

Creates a `ChatKitControl` instance that stores ChatKit options and exposes the
web component methods:

- `setOptions(next)`
- `focusComposer()`
- `setThreadId(threadId)`
- `sendUserMessage(params)`
- `setComposerValue(params)`
- `fetchUpdates()`
- `sendCustomAction(action, itemId?)`

### `<xpert-chatkit />`

Standalone Angular component that mounts the underlying `xpertai-chatkit` web
component for you. No `CUSTOM_ELEMENTS_SCHEMA` setup is required.
